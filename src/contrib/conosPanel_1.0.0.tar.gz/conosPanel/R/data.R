#' @name panel
#' @title List of four samples, each a dataset with 3000 cells in a matrix
#' @descrition Four samples in a list, each with 3000 cells. There are two samples with are bone marrow (BM), and two samples which are cord blood (CB).
#'      The names of the samples are: "MantonBM1_HiSeq_1", "MantonBM2_HiSeq_1", "MantonCB1_HiSeq_1", "MantonCB2_HiSeq_1"
#'
NULL