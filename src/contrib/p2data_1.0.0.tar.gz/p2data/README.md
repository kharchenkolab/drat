[![Build Status](https://travis-ci.org/kharchenkolab/p2data.svg?branch=main)](https://travis-ci.com/github/kharchenkolab/p2data)

# p2data

For more on using this R package, see the GitHub repository for the [pagoda2 package](https://github.com/kharchenkolab/pagoda2). The data within this package `p2data` are the 3000 bone marrow cells used for vignettes, whereby the `*rda` file `sample_BM1.rda` is approximately 6 MB in size.

 
