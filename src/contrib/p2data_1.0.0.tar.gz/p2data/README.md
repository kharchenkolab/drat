# p2data

Package with data used by pagoda2, 3000 bone marrow cells.

The `*rda` file `sample_BM1.rda` is approximately 6 MB in size.