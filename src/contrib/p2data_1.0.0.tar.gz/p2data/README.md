# p2data

 For more on using this package, see the GitHub repository for the `pagoda2` package, which is built to interact with data in this package. The data within this package are the 3000 bone marrow cells used for vignettes, whereby the `*rda` file `sample_BM1.rda` is approximately 6 MB in size.