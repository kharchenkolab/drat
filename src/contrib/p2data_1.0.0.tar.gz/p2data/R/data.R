#' @name sample_BM1
#' @title dataset of 3000 bone marrow cells loaded into a matrix 
#'
NULL
